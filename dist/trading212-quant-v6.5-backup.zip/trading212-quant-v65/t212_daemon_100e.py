#!/usr/bin/env python3
"""
Demone Quantitativo Autonomo Trading 212 (100,00 EUR / 4 Cartucce da 25,00 EUR)
Versione 4.5 — Ibrida 2+2 Senza Tetto + RADAR PREDITTIVO ONDA NOTTURNA (Wall Street + VIX + VWAP)
=================================================================================================
Come il bot evita le onde negative della notte e cavalca quelle positive:
Alle ore 17:15-17:28 (prima che Francoforte chiuda alle 17:30), Wall Street (New York) è GIÀ
aperta da quasi 2 ore (dalle 15:30). Il modulo `OvernightWaveRadar` legge in tempo reale:
  1. Nasdaq 100 / Composite (^IXIC) — il motore mondiale dei titoli tecnologici
  2. S&P 500 (^GSPC) — la direzione dei grandi fondi istituzionali USA
  3. Indice della Paura VIX (^VIX) — se sale forte, i fondi stanno scappando dal rischio
  4. Posizione del singolo titolo rispetto al suo VWAP e RSI di fine pomeriggio

Decisione Automatica alle 17:15-17:28 per ciascuna cartuccia:
  - SE RADAR = ONDA NOTTURNA POSITIVA (Wall Street verde + VIX calmo + Titolo forte sopra VWAP):
    -> MANTIENE APERTA la cartuccia durante la notte (e se c'è liquidità libera compra il leader)
       per incassare il salto positivo ("Gap Up") delle ore 09:00 del mattino dopo!
  - SE RADAR = ONDA NOTTURNA NEGATIVA / PERICOLO (Wall Street rossa o VIX in allarme o Titolo debole):
    -> ATTIVA LO SCUDO ANTI-NOTTE: vende prima delle 17:30 e mette i profitti al sicuro in
       contanti EUR, schivando il ribasso notturno e tenendo le munizioni pronte per comprare
       a sconto alle 09:01 del mattino dopo!
"""

import datetime
import json
import os
import time
import urllib.request
from typing import Dict, Any, List, Optional

from trading212_bot import (
    Trading212Client,
    Trading212AutonomousBot,
    EUR_ZERO_FEE_UNIVERSE,
    BASE_DIR,
    BOT_STATE_PATH,
)

CREDENTIALS_PATH = os.path.join(BASE_DIR, "t212_credentials.json")

ASSET_PROFILES: Dict[str, Dict[str, Any]] = {
    "DTEd_EQ": {
        "yahoo": "DTE.DE",
        "squad": "SQUADRA_1_CECCHINO_GIORNALIERO",
        "sector": "TELECOMUNICAZIONI",
        "role_desc": "Incasso Veloce Intraday (Senza Tetto)",
        "ref_price_eur": 25.90,
        "shield_activation_pct": 0.0055,
        "shield_pullback_pct": 0.0013,
    },
    "ALVd_EQ": {
        "yahoo": "ALV.DE",
        "squad": "SQUADRA_1_CECCHINO_GIORNALIERO",
        "sector": "ASSICURAZIONI_FINANZA",
        "role_desc": "Incasso Veloce Intraday (Senza Tetto)",
        "ref_price_eur": 461.60,
        "shield_activation_pct": 0.0065,
        "shield_pullback_pct": 0.0014,
    },
    "SIEd_EQ": {
        "yahoo": "SIE.DE",
        "squad": "SQUADRA_1_CECCHINO_GIORNALIERO",
        "sector": "INDUSTRIA_INFRASTRUTTURE",
        "role_desc": "Incasso Veloce / Rotazione (Senza Tetto)",
        "ref_price_eur": 279.50,
        "shield_activation_pct": 0.0085,
        "shield_pullback_pct": 0.0016,
    },
    "SAPd_EQ": {
        "yahoo": "SAP.DE",
        "squad": "SQUADRA_2_CAVALCA_ONDA",
        "sector": "SOFTWARE_CLOUD",
        "role_desc": "Cavalca-Onda Lunga & Gap Notturno Selettivo (Senza Tetto)",
        "ref_price_eur": 217.80,
        "shield_activation_pct": 0.0125,
        "shield_pullback_pct": 0.0024,
    },
    "IFXd_EQ": {
        "yahoo": "IFX.DE",
        "squad": "SQUADRA_2_CAVALCA_ONDA",
        "sector": "SEMICONDUTTORI_CHIP",
        "role_desc": "Cavalca-Onda Semiconduttori & Gap Notturno Selettivo (Senza Tetto)",
        "ref_price_eur": 49.70,
        "shield_activation_pct": 0.0135,
        "shield_pullback_pct": 0.0025,
    },
    "ASMLa_EQ": {
        "yahoo": "ASML.AS",
        "squad": "SQUADRA_2_CAVALCA_ONDA",
        "sector": "SEMICONDUTTORI_CHIP",
        "role_desc": "Cavalca-Onda AI/Chip & Gap Notturno Selettivo (Senza Tetto)",
        "ref_price_eur": 1313.00,
        "shield_activation_pct": 0.0145,
        "shield_pullback_pct": 0.0028,
    },
}


def compute_rsi(closes: List[float], period: int = 14) -> float:
    if len(closes) < period + 1:
        return 50.0
    deltas = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    recent = deltas[-period:]
    gains = sum(d for d in recent if d > 0) / period
    losses = sum(-d for d in recent if d < 0) / period
    if losses == 0:
        return 100.0 if gains > 0 else 50.0
    rs = gains / losses
    return round(100.0 - (100.0 / (1.0 + rs)), 1)


class OvernightWaveRadar:
    """
    Radar Predittivo dell'Onda Notturna (Wall Street + Indice della Paura VIX + DAX):
    Poiché New York apre alle 15:30 e Francoforte chiude alle 17:30, tra le 17:15 e le 17:28
    abbiamo quasi 2 ore di dati reali dagli USA per sapere se i grandi fondi americani stanno
    comprando (Onda Notturna Positiva -> tenere aperto per il salto delle 09:00) oppure
    vendendo (Onda Notturna Negativa -> incassare subito in EUR prima delle 17:30).
    """

    def __init__(self) -> None:
        self.last_check_ts: float = 0.0
        self.cached_radar: Dict[str, Any] = {}

    def _fetch_index_change_pct(self, symbol: str) -> float:
        url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?interval=5m&range=1d"
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0)"},
        )
        try:
            with urllib.request.urlopen(req, timeout=6) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                res = data["chart"]["result"][0]
                meta = res.get("meta", {})
                prev_close = float(meta.get("chartPreviousClose") or meta.get("previousClose") or 0.0)
                closes = [
                    float(c)
                    for c in res["indicators"]["quote"][0].get("close", [])
                    if c is not None
                ]
                if closes and prev_close > 0:
                    return round(((closes[-1] - prev_close) / prev_close) * 100.0, 2)
                if len(closes) >= 2 and closes[0] > 0:
                    return round(((closes[-1] - closes[0]) / closes[0]) * 100.0, 2)
        except Exception:
            pass
        return 0.0

    def evaluate_overnight_wave(self, force: bool = False) -> Dict[str, Any]:
        now_ts = time.time()
        if not force and self.cached_radar and (now_ts - self.last_check_ts) < 120.0:
            return self.cached_radar

        sp500_pct = self._fetch_index_change_pct("%5EGSPC")
        nasdaq_pct = self._fetch_index_change_pct("%5EIXIC")
        dax_pct = self._fetch_index_change_pct("%5EGDAXI")
        vix_pct = self._fetch_index_change_pct("%5EVIX")

        # Regola istituzionale per prevedere l'Onda Notturna:
        # - Wall Street positiva (media Nasdaq + S&P500 >= +0.10%)
        # - Indice della Paura VIX calmo (non sta esplodendo oltre +2.5%)
        us_avg_pct = round((nasdaq_pct * 0.6 + sp500_pct * 0.4), 2)
        is_positive_wave = (us_avg_pct >= 0.10 and vix_pct <= 2.5) or (
            us_avg_pct >= 0.0 and dax_pct >= 0.35 and vix_pct <= 1.0
        )

        if is_positive_wave:
            verdict = "ONDA_NOTTURNA_POSITIVA_CAVALCA_IL_GAP_09_00"
            explanation = (
                f"Wall Street spinge al rialzo (Nasdaq {nasdaq_pct:+.2f}%, S&P500 {sp500_pct:+.2f}%, "
                f"VIX {vix_pct:+.2f}%): ALTA PROBABILITÀ di salto positivo domattina alle 09:00. "
                "Il bot MANTIENE APERTE per la notte le cartucce forti sopra il VWAP!"
            )
        else:
            verdict = "ONDA_NOTTURNA_INCERTA_O_NEGATIVA_SCUDO_ATTIVO"
            explanation = (
                f"Prudenza notturna (Nasdaq {nasdaq_pct:+.2f}%, S&P500 {sp500_pct:+.2f}%, "
                f"DAX {dax_pct:+.2f}%, VIX {vix_pct:+.2f}%): alle 17:15 il bot INCASSA IN CONTANTI EUR "
                "i profitti fatti in giornata per evitare cali notturni e comprare a sconto alle 09:00!"
            )

        self.cached_radar = {
            "verdict": verdict,
            "allow_overnight_hold": is_positive_wave,
            "nasdaq_change_pct": nasdaq_pct,
            "sp500_change_pct": sp500_pct,
            "dax_change_pct": dax_pct,
            "vix_fear_change_pct": vix_pct,
            "spiegazione_strategica": explanation,
        }
        self.last_check_ts = now_ts
        return self.cached_radar


class QuantMarketScanner:
    """Scanner quantitativo a 5 minuti con Fusione Zero-Latency (Tick Real-Time Trading 212 + Storico 5m)."""

    def __init__(self) -> None:
        self.live_prices: Dict[str, float] = {
            tkr: float(prof["ref_price_eur"]) for tkr, prof in ASSET_PROFILES.items()
        }
        self.has_t212_realtime: Dict[str, bool] = {}
        # Buffer di candele a 5 minuti costruite in tempo reale (0ms) dai prezzi live di Trading 212
        self.realtime_5m_bars: Dict[str, Dict[int, Dict[str, float]]] = {
            tkr: {} for tkr in ASSET_PROFILES
        }
        self.last_scan_ts: float = 0.0
        self.cached_metrics: Dict[str, Dict[str, Any]] = {}

    def update_t212_live_price(self, ticker: str, price_eur: float) -> None:
        if price_eur > 0 and ticker in ASSET_PROFILES:
            px = round(price_eur, 4)
            self.live_prices[ticker] = px
            self.has_t212_realtime[ticker] = True
            bucket_5m = int(time.time() // 300) * 300
            bars = self.realtime_5m_bars.setdefault(ticker, {})
            if bucket_5m not in bars:
                bars[bucket_5m] = {"open": px, "high": px, "low": px, "close": px}
            else:
                b = bars[bucket_5m]
                b["high"] = max(b["high"], px)
                b["low"] = min(b["low"], px)
                b["close"] = px

    def fetch_5m_metrics(self, ticker: str) -> Dict[str, Any]:
        prof = ASSET_PROFILES[ticker]
        ysymbol = prof["yahoo"]
        url = f"https://query1.finance.yahoo.com/v8/finance/chart/{ysymbol}?interval=5m&range=1d"
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0)"},
        )
        closes: List[float] = []
        highs: List[float] = []
        lows: List[float] = []
        vols: List[float] = []
        last_yahoo_ts: int = 0
        try:
            with urllib.request.urlopen(req, timeout=6) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                result = data["chart"]["result"][0]
                meta_info = result.get("meta", {})
                reg_px = meta_info.get("regularMarketPrice")
                if reg_px and not self.has_t212_realtime.get(ticker):
                    self.live_prices[ticker] = round(float(reg_px), 4)
                timestamps = result.get("timestamp", [])
                quote = result["indicators"]["quote"][0]
                for ts, c, h, l, v in zip(
                    timestamps,
                    quote.get("close", []),
                    quote.get("high", []),
                    quote.get("low", []),
                    quote.get("volume", []),
                ):
                    if c is not None and h is not None and l is not None:
                        closes.append(float(c))
                        highs.append(float(h))
                        lows.append(float(l))
                        vols.append(float(v or 0.0))
                        last_yahoo_ts = int(ts)
        except Exception:
            pass

        # BLINDATURA #11: Fusione Zero-Latency (0ms)
        # Incolla in cima alle candele di Yahoo (che su XETRA hanno 15m di ritardo)
        # le candele costruite in tempo reale al secondo dai prezzi di Trading 212!
        rt_bars = self.realtime_5m_bars.get(ticker, {})
        avg_vol_est = (sum(vols[-6:]) / 6.0) if len(vols) >= 6 else 1000.0
        for b_ts in sorted(rt_bars.keys()):
            if b_ts > last_yahoo_ts:
                b = rt_bars[b_ts]
                closes.append(b["close"])
                highs.append(b["high"])
                lows.append(b["low"])
                vols.append(avg_vol_est)

        if closes:
            last_c = self.live_prices.get(ticker, closes[-1])
            if abs(last_c - closes[-1]) > 1e-4:
                closes.append(last_c)
                highs.append(max(last_c, closes[-2]))
                lows.append(min(last_c, closes[-2]))
                vols.append(avg_vol_est)
            rsi_14 = compute_rsi(closes, 14)
            day_high = max(max(highs), last_c) if highs else last_c
            dip_from_high_pct = ((last_c - day_high) / day_high) * 100.0 if day_high > 0 else 0.0
            tot_vol = sum(vols)
            vwap = (
                sum(c * v for c, v in zip(closes, vols)) / tot_vol
                if tot_vol > 0
                else sum(closes) / len(closes)
            )
            vwap_dist_pct = ((last_c - vwap) / vwap) * 100.0 if vwap > 0 else 0.0
        else:
            last_c = self.live_prices.get(ticker, float(prof["ref_price_eur"]))
            rsi_14 = 48.0
            dip_from_high_pct = -0.50
            vwap_dist_pct = -0.15

        rsi_score = max(0.0, min(50.0, (65.0 - rsi_14) * 1.25))
        dip_score = max(0.0, min(35.0, abs(min(0.0, dip_from_high_pct)) * 18.0))
        vwap_score = max(0.0, min(15.0, -vwap_dist_pct * 10.0)) if vwap_dist_pct < 0 else 0.0
        quant_score = round(min(100.0, rsi_score + dip_score + vwap_score), 1)

        # Distinzione Chirurgica tra VERO POSITIVO (Super-Trend) e FALSO POSITIVO (Inversione Sinusoidale):
        # Un RSI alto (> 65) mentre il prezzo fa nuovi massimi coi volumi è un VERO POSITIVO (Breakout)!
        # È un FALSO POSITIVO solo se tutte e 3 le condizioni di inversione avvengono insieme:
        # 1) Tirato in alto (RSI > 66)
        # 2) La candela ha GIÀ girato in giù (closes[-1] < closes[-2])
        # 3) I volumi di acquisto stanno scendendo sotto la media (esaurimento compratori)
        if len(closes) >= 6:
            price_turning_down = (closes[-1] < closes[-2])
            falling_knife = (closes[-1] < closes[-2] and closes[-2] < closes[-3])
            green_hook_confirmed = not falling_knife and (closes[-1] >= closes[-2] or lows[-1] >= lows[-2])
            slope_rising = (closes[-1] >= closes[-3])
            avg_recent_vol = sum(vols[-6:-1]) / 5.0 if sum(vols[-6:-1]) > 0 else 1.0
            volume_drying_up = (vols[-1] < avg_recent_vol * 0.90)
            # BLINDATURA #8: Calcolo ATR (Average True Range) a 5m per Scudo Elastico sulla Volatilità
            tr_pcts: List[float] = []
            start_idx = max(1, len(closes) - 14)
            for i in range(start_idx, len(closes)):
                prev_c = closes[i - 1]
                if prev_c > 0:
                    tr = max(
                        highs[i] - lows[i],
                        abs(highs[i] - prev_c),
                        abs(lows[i] - prev_c),
                    )
                    tr_pcts.append(tr / prev_c)
            atr_5m_pct = (sum(tr_pcts) / len(tr_pcts)) if tr_pcts else 0.0018
        else:
            price_turning_down = False
            green_hook_confirmed = True
            slope_rising = True
            volume_drying_up = False
            atr_5m_pct = 0.0018

        # Fattore elastico ATR (tra 0.80x su mercato piatto e 1.30x su mercato esplosivo)
        vol_scale = round(max(0.80, min(1.30, atr_5m_pct / 0.0018)), 2)
        base_act = float(prof["shield_activation_pct"])
        base_pull = float(prof["shield_pullback_pct"])
        elastic_shield_act = round(base_act * vol_scale, 4)
        elastic_shield_pull = round(base_pull * vol_scale, 4)

        if rsi_14 > 66.0 and price_turning_down and volume_drying_up:
            sine_phase = "CRESTA_IN_INVERSIONE_FALSO_POSITIVO"
            strong_for_overnight = False
        elif rsi_14 > 62.0 and not price_turning_down:
            sine_phase = "SUPER_TREND_VERO_POSITIVO_BREAKOUT"
            strong_for_overnight = True
        elif 38.0 <= rsi_14 <= 62.0 and slope_rising and vwap_dist_pct >= -0.20:
            sine_phase = "ONDA_ASCENDENTE_SANA_VERO_POSITIVO"
            strong_for_overnight = True
        elif rsi_14 < 38.0:
            sine_phase = (
                "VALLE_CON_UNCINO_VERDE_PRONTO_ACQUISTO"
                if green_hook_confirmed
                else "COLTELLO_IN_CADUTA_ATTENDERE_UNCINO_VERDE"
            )
            strong_for_overnight = False
        else:
            sine_phase = "ONDA_DISCENDENTE_O_DEBOLE"
            strong_for_overnight = False

        return {
            "ticker": ticker,
            "name": EUR_ZERO_FEE_UNIVERSE[ticker]["name"],
            "squad": prof["squad"],
            "sector": prof["sector"],
            "role_desc": prof["role_desc"],
            "live_price_eur": round(last_c, 2),
            "rsi_5m": rsi_14,
            "dip_from_high_pct": round(dip_from_high_pct, 2),
            "vwap_dist_pct": round(vwap_dist_pct, 2),
            "atr_5m_volatility_pct": round(atr_5m_pct * 100, 3),
            "atr_elastic_scale": vol_scale,
            "quant_buy_score": quant_score,
            "fase_onda_sinusoidale": sine_phase,
            "green_hook_confirmed": green_hook_confirmed,
            "strong_for_overnight": strong_for_overnight,
            "shield_activation_pct": round(elastic_shield_act * 100, 2),
            "shield_pullback_pct": round(elastic_shield_pull * 100, 2),
            "elastic_shield_act_raw": elastic_shield_act,
            "elastic_shield_pull_raw": elastic_shield_pull,
            "pre_shield_breakeven_trigger_pct": 0.60,
            "pre_shield_breakeven_floor_pct": 0.25,
            "tetto_massimo_rialzo": "NESSUN TETTO (Lascia correre i profitti)",
        }

    def scan_all(self, force: bool = False) -> Dict[str, Dict[str, Any]]:
        now_ts = time.time()
        # Ricalcola sempre con la fusione Zero-Latency a 0ms dei prezzi live di Trading 212
        results: Dict[str, Dict[str, Any]] = {}
        for tkr in ASSET_PROFILES:
            results[tkr] = self.fetch_5m_metrics(tkr)
        self.cached_metrics = results
        self.last_scan_ts = now_ts
        return results


class HybridUncappedIntelligence:
    """
    Motore Ibrido 2+2 Senza Tetto + Selettore Onda Notturna (17:15-17:30):
    - Di giorno: non taglia MAI i rialzi mentre corrono (Scudo Mobile Senza Tetto).
    - Alle 17:15-17:30: interroga il Radar Wall Street + VIX + VWAP:
      * Se si prevede un'Onda Notturna Positiva E il titolo è forte sopra il VWAP -> MANTIENE APERTO
        per catturare il salto ("Gap Up") delle 09:00 del mattino dopo!
      * Se si prevede un'Onda Notturna Negativa/Incerta (o il titolo è debole) -> VENDE E INCASSA
        prima delle 17:30 per proteggere al 100% i profitti!
    """

    def __init__(self) -> None:
        self.peak_pnl_pct: Dict[str, float] = {}
        self.last_sell_price: Dict[str, float] = {}
        self.last_sell_time: Dict[str, float] = {}
        self.position_open_time: Dict[str, float] = {}
        self._load_persisted_peaks()

    def _load_persisted_peaks(self) -> None:
        if os.path.exists(BOT_STATE_PATH):
            try:
                with open(BOT_STATE_PATH, "r", encoding="utf-8") as f:
                    st = json.load(f)
                for c in st.get("cartucce_4x25_eur", []):
                    tkr = c.get("ticker")
                    pk = c.get("peak_pnl_pct")
                    if tkr and pk is not None:
                        self.peak_pnl_pct[tkr] = float(pk) / 100.0
            except Exception:
                pass

    def get_intraday_regime(self, now: datetime.datetime) -> Dict[str, Any]:
        hm = now.hour * 60 + now.minute
        is_friday = (now.weekday() == 4)
        if now.weekday() >= 5:
            return {
                "code": "WEEKEND_BORSA_CHIUSA",
                "description": "Mercati chiusi per il weekend",
                "market_open": False,
                "allow_new_buys": False,
                "is_pre_close_window": False,
                "is_morning_gap_harvest": False,
                "is_friday_pre_weekend": False,
            }
        if hm < 9 * 60 or hm >= 17 * 60 + 30:
            return {
                "code": "DOPOBORSA_NOTTURNO",
                "description": "Borsa XETRA chiusa (09:00-17:30)",
                "market_open": False,
                "allow_new_buys": False,
                "is_pre_close_window": False,
                "is_morning_gap_harvest": False,
                "is_friday_pre_weekend": False,
            }
        if 9 * 60 <= hm < 9 * 60 + 30:
            return {
                "code": "FASE_1A_RACCOLTO_GAP_MATTUTINO_ANTI_GAP_FILL",
                "description": "09:00-09:30: Scudo Ultra-Reattivo (+0,50% / -0,14%) per blindare il salto della notte prima che si sgonfi",
                "market_open": True,
                "allow_new_buys": True,
                "is_pre_close_window": False,
                "is_morning_gap_harvest": True,
                "is_friday_pre_weekend": False,
            }
        if 9 * 60 + 30 <= hm < 10 * 60 + 30:
            return {
                "code": "FASE_1B_SPRINT_MATTUTINO_SENZA_TETTO",
                "description": "09:30-10:30: Sprint direzionale mattutino senza tetto ai rialzi",
                "market_open": True,
                "allow_new_buys": True,
                "is_pre_close_window": False,
                "is_morning_gap_harvest": False,
                "is_friday_pre_weekend": False,
            }
        if 14 * 60 + 28 <= hm <= 14 * 60 + 35:
            return {
                "code": "PAUSA_ANTI_SHOCK_DATI_MACRO_USA_14_30",
                "description": "14:28-14:35: Scudo Anti-Stop-Hunting durante uscita dati Inflazione/Lavoro USA (Scudi vendita attivi, nuovi acquisti in pausa 7 min)",
                "market_open": True,
                "allow_new_buys": False,
                "is_pre_close_window": False,
                "is_morning_gap_harvest": False,
                "is_friday_pre_weekend": False,
            }
        if 10 * 60 + 30 <= hm < 15 * 60 + 30:
            return {
                "code": "FASE_2_IBRIDA_2X2_BLINDATA_V5",
                "description": "10:30-15:30: 2 Cartucce Cecchino + 2 Cavalca-Onda (con Pre-Scudo Salva-Utile a +0,60% e Filtro Uncino Verde)",
                "market_open": True,
                "allow_new_buys": True,
                "is_pre_close_window": False,
                "is_morning_gap_harvest": False,
                "is_friday_pre_weekend": False,
            }
        if 17 * 60 + 15 <= hm < 17 * 60 + 30:
            return {
                "code": "FASE_4_RADAR_SELETTORE_ONDA_NOTTURNA_E_WEEKEND",
                "description": "17:15-17:30: Selettore Vero/Falso Positivo + Evacuazione Totale su Pericolo USA + Scudo Weekend Venerdì",
                "market_open": True,
                "allow_new_buys": True,
                "is_pre_close_window": True,
                "is_morning_gap_harvest": False,
                "is_friday_pre_weekend": is_friday,
            }
        return {
            "code": "FASE_3_ONDA_WALL_STREET_SENZA_TETTO",
            "description": "15:30-17:15: Spinta USA - Pre-Scudo Salva-Utile + Scudo Mobile Senza Tetto",
            "market_open": True,
            "allow_new_buys": True,
            "is_pre_close_window": False,
            "is_morning_gap_harvest": False,
            "is_friday_pre_weekend": False,
        }

    def evaluate_uncapped_exit(
        self,
        ticker: str,
        pnl_pct: float,
        regime: Dict[str, Any],
        best_bench_score: float,
        overnight_radar: Dict[str, Any],
        ticker_metrics: Dict[str, Any],
        realized_net_eur: float = 0.0,
        has_green_hook_bench: bool = False,
    ) -> Optional[str]:
        prof = ASSET_PROFILES.get(ticker, ASSET_PROFILES["SAPd_EQ"])
        # BLINDATURA #8: Usa lo Scudo Elastico adattato alla volatilità ATR a 5m
        shield_act = float(ticker_metrics.get("elastic_shield_act_raw", prof["shield_activation_pct"]))
        shield_pull = float(ticker_metrics.get("elastic_shield_pull_raw", prof["shield_pullback_pct"]))

        # BLINDATURA #10: Cassaforte Giornaliera (High-Water Mark Profit Lock)
        # Se abbiamo già incassato >= +1,80 EUR in cassa, il Pre-Scudo Salva-Utile scatta già a +0,42%!
        daily_vault_active = (realized_net_eur >= 1.80)
        breakeven_trigger = 0.0042 if daily_vault_active else 0.0060
        breakeven_floor = 0.0020 if daily_vault_active else 0.0025

        prev_peak = self.peak_pnl_pct.get(ticker, pnl_pct)
        new_peak = max(prev_peak, pnl_pct)
        self.peak_pnl_pct[ticker] = new_peak

        # BLINDATURA #3: Raccolto del Salto Mattutino 09:00-09:30 (Anti-Gap-Fill)
        # Se un titolo portato dalla notte apre col botto (>= +0.50%), lo scudo si stringe a 0.14%:
        # finché sale lo lascia correre, ma appena accenna a sgonfiarsi incassa subito il salto!
        if regime.get("is_morning_gap_harvest"):
            if new_peak >= 0.0050 and (new_peak - pnl_pct) >= 0.0014 and pnl_pct >= 0.0030:
                return (
                    f"BLINDATURA #3 - RACCOLTO GAP MATTUTINO (09:00-09:30): blindato salto notturno "
                    f"dal picco +{new_peak*100:.2f}% a +{pnl_pct*100:.2f}% prima del Gap-Fill!"
                )

        # BLINDATURA #1 (Stadio 2) + BLINDATURA #8 (ATR Elastico): Scudo Mobile Senza Tetto
        if new_peak >= shield_act and (new_peak - pnl_pct) >= shield_pull and pnl_pct >= 0.0040:
            return (
                f"SCUDO MOBILE ELASTICO SENZA TETTO ({prof['squad']}): cavalcato rialzo fino al picco "
                f"di +{new_peak*100:.2f}% e incassato su inversione a +{pnl_pct*100:.2f}%"
            )

        # BLINDATURA #1 (Stadio 1): Pre-Scudo "Salva-Utile" (Break-Even Lock)
        # Appena un titolo tocca >= +0.60% (o +0.42% in modalità Cassaforte Giornaliera), alza una sbarra protettiva!
        if new_peak >= breakeven_trigger and pnl_pct <= breakeven_floor:
            return (
                f"BLINDATURA #1 - PRE-SCUDO SALVA-UTILE (Break-Even Lock): {ticker} aveva toccato "
                f"il picco di +{new_peak*100:.2f}% e ha ritracciato al pavimento garantito di +{pnl_pct*100:.2f}%!"
            )

        # BLINDATURE #4 e #5: Finestra Pre-Chiusura 17:15-17:30 (Notte & Weekend)
        sine_phase = ticker_metrics.get("fase_onda_sinusoidale", "")
        stock_is_strong = bool(ticker_metrics.get("strong_for_overnight", False))
        if regime.get("is_pre_close_window"):
            wall_street_positive = bool(overnight_radar.get("allow_overnight_hold", False))
            nasdaq_chg = float(overnight_radar.get("nasdaq_change_pct", 0.0))
            vix_chg = float(overnight_radar.get("vix_fear_change_pct", 0.0))

            # A) Blocco Falso Positivo (Tripla prova di inversione dalla cresta)
            if sine_phase == "CRESTA_IN_INVERSIONE_FALSO_POSITIVO" and pnl_pct >= 0.0010:
                return (
                    f"BLOCCO FALSO POSITIVO NOTTURNO (17:15): {ticker} mostra tripla prova di inversione "
                    f"dalla cresta (RSI {ticker_metrics.get('rsi_5m')} + candela rossa + calo volumi) -> "
                    f"INCASSO SUBITO +{pnl_pct*100:.2f}%!"
                )

            # B) BLINDATURA #5: Scudo Weekend del Venerdì (63 ore di mercati chiusi)
            if regime.get("is_friday_pre_weekend") and pnl_pct >= 0.0010:
                super_friday_ok = (
                    sine_phase == "SUPER_TREND_VERO_POSITIVO_BREAKOUT"
                    and nasdaq_chg >= 0.50
                    and vix_chg <= 0.0
                )
                if not super_friday_ok:
                    return (
                        f"BLINDATURA #5 - SCUDO WEEKEND VENERDÌ (17:15): incasso +{pnl_pct*100:.2f}% "
                        f"in EUR per evitare 63 ore di rischio geopolitico nel fine settimana!"
                    )

            # C) BLINDATURA #4: Evacuazione Totale su Pericolo Wall Street
            if not wall_street_positive:
                if pnl_pct >= 0.0005:
                    return (
                        f"BLINDATURA #4 - EVACUAZIONE NOTTURNA SU PERICOLO USA: Wall Street negativa -> "
                        f"metto in salvo +{pnl_pct*100:.2f}% in contanti prima della notte!"
                    )
                if -0.0020 <= pnl_pct < 0.0005 and not stock_is_strong:
                    return (
                        f"BLINDATURA #4 - USCITA QUASI-PARI PRE-TEMPESTA NOTTURNA ({pnl_pct*100:+.2f}%): "
                        f"libero la cartuccia per ricomprare a sconto domattina alle 09:00!"
                    )

            # D) Se Wall Street è positiva: tieni i Veri Positivi, incassa i titoli deboli in utile (>= +0.30%)
            if wall_street_positive and stock_is_strong:
                return None
            if pnl_pct >= 0.0030:
                return (
                    f"SCUDO SELETTIVO 17:15: titolo in fase '{sine_phase}' -> "
                    f"incasso +{pnl_pct*100:.2f}% prima della chiusura!"
                )

        # Rotazione Costo-Opportunità in Utile (per Squadra 1 Veloce):
        opened_at = self.position_open_time.setdefault(ticker, time.time())
        hours_open = (time.time() - opened_at) / 3600.0
        if (
            prof["squad"] == "SQUADRA_1_CECCHINO_GIORNALIERO"
            and hours_open >= 2.5
            and 0.0040 <= pnl_pct < shield_act
            and best_bench_score >= 78.0
        ):
            return (
                f"ROTAZIONE SQUADRA VELOCE: incasso +{pnl_pct*100:.2f}% per spostare cartuccia "
                f"su occasione estrema (Quant Score {best_bench_score:.0f}/100)"
            )

        # BLINDATURA #9: Sblocco Chirurgico del Titolo Immobile (Time-Stop > 4h + Zainetto Fiscale 730)
        # Se un titolo è bloccato e debole (sotto il VWAP) da oltre 4 ore con piccola perdita (-0,60% / -1,80%),
        # mentre in panchina c'è un razzo (Score >= 65 con Uncino Verde) e abbiamo già abbondante utile in cassa:
        est_loss_eur = abs(pnl_pct * 25.0)
        if (
            hours_open >= 4.0
            and -0.0180 <= pnl_pct <= -0.0060
            and not stock_is_strong
            and has_green_hook_bench
            and best_bench_score >= 65.0
            and realized_net_eur >= max(1.00, est_loss_eur * 2.2)
        ):
            return (
                f"BLINDATURA #9 - SBLOCCO TITOLO IMMOBILE (>4h) + ZAINETTO 730 ({pnl_pct*100:+.2f}%): "
                f"scarico minusvalenza nel 730 e ruoto subito su occasione d'oro (Score {best_bench_score:.0f}/100)!"
            )

        return None

    def register_sell(self, ticker: str, sell_price_eur: float) -> None:
        self.peak_pnl_pct.pop(ticker, None)
        self.position_open_time.pop(ticker, None)
        self.last_sell_price[ticker] = sell_price_eur
        self.last_sell_time[ticker] = time.time()

    def can_buy_ticker(self, ticker: str, live_price_eur: float) -> bool:
        if ticker not in self.last_sell_price:
            return True
        last_px = self.last_sell_price[ticker]
        elapsed_min = (time.time() - self.last_sell_time.get(ticker, 0.0)) / 60.0
        if live_price_eur <= last_px * (1.0 - 0.0045):
            return True
        return elapsed_min >= 30.0


def load_client() -> Trading212Client:
    with open(CREDENTIALS_PATH, "r", encoding="utf-8") as f:
        creds = json.load(f)
    return Trading212Client(
        api_key=creds["api_key"],
        api_secret=creds.get("api_secret"),
        mode=creds.get("mode", "demo"),
    )


def run_cycle(
    bot: Trading212AutonomousBot,
    intel: HybridUncappedIntelligence,
    scanner: QuantMarketScanner,
    radar: OvernightWaveRadar,
    cycle_num: int,
) -> Dict[str, Any]:
    assert bot.client is not None
    client = bot.client
    bot.tax_tracker.load()

    now = datetime.datetime.now()
    regime = intel.get_intraday_regime(now)

    # 1. Leggi posizioni aperte e ordini pendenti da Trading 212
    positions = client.get_open_positions()
    time.sleep(2.5)
    pending_orders = client.get_pending_orders()
    time.sleep(2.5)

    pos_by_ticker: Dict[str, Dict[str, Any]] = {p.get("ticker", ""): p for p in positions}
    pending_by_ticker: Dict[str, Dict[str, Any]] = {
        o.get("ticker", ""): o for o in pending_orders if o.get("ticker")
    }

    for tkr, p in pos_by_ticker.items():
        cur_px = float(p.get("currentPrice", 0.0))
        scanner.update_t212_live_price(tkr, cur_px)

    # 2. Scansione quantitativa 5m + Radar Onda Notturna (Wall Street + VIX)
    quant_metrics = scanner.scan_all()
    overnight_status = radar.evaluate_overnight_wave()

    # BLINDATURA #6: Interesse Composto Automatico di Kelly (Auto-Compounding)
    realized_net_eur = round(
        float(bot.tax_tracker.data.get("plusvalenze_lorde_eur", 0.0))
        - float(bot.tax_tracker.data.get("minusvalenze_lorde_eur", 0.0)),
        2,
    )
    compounded_budget_eur = round(bot.total_budget_eur + max(0.0, realized_net_eur), 2)
    dynamic_cartridge_eur = round(compounded_budget_eur / bot.cartridges, 2)
    daily_vault_active = (realized_net_eur >= 1.80)

    bench_candidates = [
        m
        for tkr, m in quant_metrics.items()
        if tkr not in pos_by_ticker and tkr not in pending_by_ticker
    ]
    bench_scores = [float(m["quant_buy_score"]) for m in bench_candidates]
    best_bench_score = max(bench_scores) if bench_scores else 0.0
    has_green_hook_bench = any(
        bool(m.get("green_hook_confirmed")) and float(m["quant_buy_score"]) >= 65.0
        for m in bench_candidates
    )

    invested_100e = 0.0
    unrealized_pnl_100e = 0.0
    cartridge_statuses: List[Dict[str, Any]] = []
    actions_taken: List[str] = []

    # 3. Valuta posizioni aperte con logica V6.0 Istituzionale (10 Blindature)
    slot_idx = 1
    for tkr, p in list(pos_by_ticker.items()):
        if tkr not in EUR_ZERO_FEE_UNIVERSE:
            continue
        meta = EUR_ZERO_FEE_UNIVERSE[tkr]
        prof = ASSET_PROFILES.get(tkr, ASSET_PROFILES["SAPd_EQ"])
        tkr_m = quant_metrics.get(tkr, {})
        qty_open = float(p.get("quantity", 0.0))
        avg_price = float(p.get("averagePrice", 0.0))
        cur_price = float(p.get("currentPrice", avg_price))
        ppl = float(p.get("ppl", (cur_price - avg_price) * qty_open))
        cost_eur = round(qty_open * avg_price, 2)
        pnl_pct = (cur_price - avg_price) / avg_price if avg_price > 0 else 0.0

        # Ribilanciamento automatico se una cartuccia supera 1.24x la taglia composta
        max_allowed_cartridge = max(31.00, round(dynamic_cartridge_eur * 1.24, 2))
        if cost_eur > max_allowed_cartridge and regime["market_open"]:
            target_qty = round(dynamic_cartridge_eur / cur_price, 2)
            if target_qty * cur_price > (dynamic_cartridge_eur + 2.00) and target_qty > 0.01:
                target_qty = round(target_qty - 0.01, 2)
            excess_qty = round(qty_open - target_qty, 2)
            if excess_qty >= 0.01:
                client.place_market_order(ticker=tkr, quantity=-excess_qty)
                closed_op = bot.tax_tracker.record_sell(
                    ticker=tkr,
                    sell_qty=excess_qty,
                    sell_price_eur=cur_price,
                )
                qty_open = round(qty_open - excess_qty, 2)
                cost_eur = round(qty_open * avg_price, 2)
                ppl = round((cur_price - avg_price) * qty_open, 2)
                actions_taken.append(
                    f"RIBILANCIAMENTO CARTUCCIA COMPOSTA ({dynamic_cartridge_eur:.2f} EUR) su {tkr}: vendute {excess_qty} azioni in eccesso "
                    f"a {cur_price:.2f} EUR (Utile fiscale: {closed_op['risultato_fiscale_eur']:+.2f} EUR)"
                )
                time.sleep(2.5)

        # A) Valuta Scudo Mobile Elastico Senza Tetto + Selettore Onda Notturna + Time-Stop
        exit_reason = intel.evaluate_uncapped_exit(
            tkr,
            pnl_pct,
            regime,
            best_bench_score,
            overnight_status,
            tkr_m,
            realized_net_eur=realized_net_eur,
            has_green_hook_bench=has_green_hook_bench,
        )
        if exit_reason and regime["market_open"]:
            order_res = client.place_market_order(ticker=tkr, quantity=-qty_open)
            closed_op = bot.tax_tracker.record_sell(
                ticker=tkr,
                sell_qty=qty_open,
                sell_price_eur=cur_price,
            )
            intel.register_sell(tkr, cur_price)
            msg = (
                f"{exit_reason} su {tkr} ({meta['name']}): vendute {qty_open} azioni "
                f"a {cur_price:.2f} EUR (Risultato fiscale: {closed_op['risultato_fiscale_eur']:+.2f} EUR, 0,00 EUR comm.)"
            )
            actions_taken.append(msg)
            pos_by_ticker.pop(tkr, None)
            time.sleep(2.5)
            continue

        # B) Verifica Stop-Loss di Emergenza (-3.0%)
        if pnl_pct <= -0.0300 and regime["market_open"]:
            order_res = client.place_market_order(ticker=tkr, quantity=-qty_open)
            closed_op = bot.tax_tracker.record_sell(
                ticker=tkr,
                sell_qty=qty_open,
                sell_price_eur=cur_price,
            )
            intel.register_sell(tkr, cur_price)
            msg = (
                f"STOP-LOSS PROTETTIVO ({pnl_pct*100:.2f}%) su {tkr}: vendute {qty_open} azioni "
                f"a {cur_price:.2f} EUR"
            )
            actions_taken.append(msg)
            pos_by_ticker.pop(tkr, None)
            time.sleep(2.5)
            continue

        peak_now = intel.peak_pnl_pct.get(tkr, pnl_pct)
        shield_act = float(tkr_m.get("elastic_shield_act_raw", prof["shield_activation_pct"]))
        shield_pull = float(tkr_m.get("elastic_shield_pull_raw", prof["shield_pullback_pct"]))
        shield_is_armed = peak_now >= shield_act
        breakeven_trigger = 0.0042 if daily_vault_active else 0.0060
        breakeven_floor_pct = 0.20 if daily_vault_active else 0.25
        pre_shield_breakeven_armed = peak_now >= breakeven_trigger
        if shield_is_armed:
            current_floor_pct = round((peak_now - shield_pull) * 100, 2)
        elif pre_shield_breakeven_armed:
            current_floor_pct = breakeven_floor_pct
        else:
            current_floor_pct = None

        overnight_decision_preview = (
            "TIENI PER SALTO 09:00 (Onda Positiva)"
            if (overnight_status.get("allow_overnight_hold") and tkr_m.get("strong_for_overnight"))
            else "INCASSA PRIMA DELLE 17:30 SE IN UTILE (Protezione Onda Negativa)"
        )

        invested_100e += cost_eur
        unrealized_pnl_100e += ppl
        cartridge_statuses.append({
            "slot": slot_idx,
            "ticker": tkr,
            "name": meta["name"],
            "squadra": prof["squad"],
            "settore_markowitz": prof["sector"],
            "ruolo": prof["role_desc"],
            "status": "ESEGUITA_IN_PORTAFOGLIO",
            "quantity": qty_open,
            "avg_price_eur": round(avg_price, 2),
            "current_price_eur": round(cur_price, 2),
            "invested_eur": cost_eur,
            "pnl_eur": round(ppl, 2),
            "pnl_pct": round(pnl_pct * 100, 2),
            "peak_pnl_pct": round(peak_now * 100, 2),
            "tetto_massimo_guadagno": "NESSUN TETTO (Uncapped)",
            "pre_scudo_salva_utile_attivo": pre_shield_breakeven_armed,
            "scudo_mobile_elastico_atr_si_attiva_a_pct": round(shield_act * 100, 2),
            "scudo_mobile_attivo_ora": shield_is_armed,
            "livello_incasso_protetto_pct": current_floor_pct,
            "fase_onda_sinusoidale": tkr_m.get("fase_onda_sinusoidale", "N/A"),
            "decisione_notturna_prevista_17_15": overnight_decision_preview,
            "rsi_5m": tkr_m.get("rsi_5m", 50.0),
        })
        slot_idx += 1

    # 4. Conta eventuali ordini pendenti
    for tkr, o in pending_by_ticker.items():
        if tkr in EUR_ZERO_FEE_UNIVERSE and tkr not in pos_by_ticker:
            meta = EUR_ZERO_FEE_UNIVERSE[tkr]
            prof = ASSET_PROFILES.get(tkr, ASSET_PROFILES["SAPd_EQ"])
            invested_100e += dynamic_cartridge_eur
            cartridge_statuses.append({
                "slot": slot_idx,
                "ticker": tkr,
                "name": meta["name"],
                "squadra": prof["squad"],
                "settore_markowitz": prof["sector"],
                "status": "ORDINE_IN_CODA",
                "order_id": o.get("id"),
                "quantity": o.get("quantity"),
                "invested_eur": dynamic_cartridge_eur,
            })
            slot_idx += 1

    # 5. INGRESSO BILANCIATO 2+2 CON VINCOLO SETTORIALE DI MARKOWITZ E INTERESSE COMPOSTO
    active_count = len(cartridge_statuses)
    ranked_candidates = sorted(
        quant_metrics.values(),
        key=lambda m: float(m["quant_buy_score"]),
        reverse=True,
    )

    max_investable_before_4th = round(compounded_budget_eur - 18.00, 2)
    if regime["allow_new_buys"] and active_count < bot.cartridges and invested_100e <= max_investable_before_4th:
        sq1_count = sum(
            1 for c in cartridge_statuses if c.get("squadra") == "SQUADRA_1_CECCHINO_GIORNALIERO"
        )
        sq2_count = sum(
            1 for c in cartridge_statuses if c.get("squadra") == "SQUADRA_2_CAVALCA_ONDA"
        )
        active_sectors = {
            c.get("settore_markowitz")
            for c in cartridge_statuses
            if c.get("settore_markowitz")
        }

        for cand in ranked_candidates:
            if active_count >= bot.cartridges or invested_100e > max_investable_before_4th:
                break
            tkr = cand["ticker"]
            if tkr in pos_by_ticker or tkr in pending_by_ticker:
                continue
            cand_squad = cand["squad"]
            cand_sector = cand["sector"]
            if cand_squad == "SQUADRA_1_CECCHINO_GIORNALIERO" and sq1_count >= 2:
                continue
            if cand_squad == "SQUADRA_2_CAVALCA_ONDA" and sq2_count >= 2:
                continue
            # BLINDATURA #7: Vincolo di Markowitz (Mai 2 cartucce nello stesso settore industriale, es. mai ASML + Infineon insieme!)
            if cand_sector in active_sectors:
                continue

            live_px = float(cand["live_price_eur"])
            score = float(cand["quant_buy_score"])
            rsi_5m = float(cand["rsi_5m"])

            if not intel.can_buy_ticker(tkr, live_px):
                continue

            # Se siamo nella finestra 17:15-17:30, compra per la notte SOLO se il Radar prevede Onda Positiva!
            if regime.get("is_pre_close_window"):
                if not (overnight_status.get("allow_overnight_hold") and cand.get("strong_for_overnight")):
                    continue
            else:
                # BLINDATURA #2 (Uncino Verde) + BLINDATURA #10 (Cassaforte Giornaliera)
                min_required_score = 55.0 if daily_vault_active else 30.0
                if rsi_5m > 58.0 or score < min_required_score or not cand.get("green_hook_confirmed", True):
                    continue

            remaining_budget = round(compounded_budget_eur - invested_100e, 2)
            alloc_eur = min(dynamic_cartridge_eur, remaining_budget)
            if alloc_eur < 18.00:
                break

            qty_to_buy = round(alloc_eur / live_px, 2)
            if qty_to_buy <= 0:
                continue

            try:
                meta = EUR_ZERO_FEE_UNIVERSE[tkr]
                order_res = client.place_market_order(ticker=tkr, quantity=qty_to_buy)
                est_cost = round(qty_to_buy * live_px, 2)
                bot.tax_tracker.record_buy(ticker=tkr, quantity=qty_to_buy, price_eur=live_px)
                intel.position_open_time[tkr] = time.time()
                invested_100e += est_cost
                active_count += 1
                active_sectors.add(cand_sector)
                if cand_squad == "SQUADRA_1_CECCHINO_GIORNALIERO":
                    sq1_count += 1
                else:
                    sq2_count += 1
                msg = (
                    f"INGRESSO V6.0 MARKOWITZ+KELLY ({cand_squad} / {cand_sector}) -> BUY {qty_to_buy} {tkr} ({meta['name']}) "
                    f"per {est_cost:.2f} EUR | Score: {score}/100 (RSI 5m: {rsi_5m}) | Order ID: {order_res.get('id')}"
                )
                actions_taken.append(msg)
                cartridge_statuses.append({
                    "slot": slot_idx,
                    "ticker": tkr,
                    "name": meta["name"],
                    "squadra": cand_squad,
                    "settore_markowitz": cand_sector,
                    "status": "APPENA_ACQUISTATA_V6",
                    "order_id": order_res.get("id"),
                    "quantity": qty_to_buy,
                    "invested_eur": est_cost,
                })
                slot_idx += 1
                time.sleep(2.5)
            except Exception as e:
                actions_taken.append(f"Nota su ingresso 2+2 {tkr}: {e}")

    realized_net_eur = round(
        float(bot.tax_tracker.data.get("plusvalenze_lorde_eur", 0.0))
        - float(bot.tax_tracker.data.get("minusvalenze_lorde_eur", 0.0)),
        2,
    )
    virtual_100e_equity = round(bot.total_budget_eur + realized_net_eur + unrealized_pnl_100e, 2)
    free_cash_100e = round(max(0.0, compounded_budget_eur - invested_100e), 2)

    # 6. Verifica Target Annuale +30% (130,00 EUR)
    if virtual_100e_equity >= bot.target_equity_eur:
        bot.liquidate_all_for_withdrawal()
        actions_taken.append(
            f"TARGET +30% RAGGIUNTO ({virtual_100e_equity:.2f} EUR >= 130,00 EUR)! "
            "Liquidazione totale eseguita a 0,00 EUR commissioni."
        )

    state = {
        "timestamp": now.isoformat(timespec="seconds"),
        "cycle": cycle_num,
        "mode": "INSTITUTIONAL_ZERO_LATENCY_V6_5_12_SHIELDS",
        "blindature_attive_v6_istituzionali": [
            "1. Pre-Scudo Salva-Utile (Break-Even Lock: picco >= +0,60% -> pavimento garantito +0,25%)",
            "2. Filtro Uncino Verde sugli Acquisti (Anti-Falling-Knife)",
            "3. Raccolto Gap Mattutino 09:00-09:30 (Anti-Gap-Fill: scudo stretto -0,14% sopra +0,50%)",
            "4. Evacuazione Notturna Totale alle 17:15 se Wall Street è negativa",
            "5. Scudo Weekend del Venerdì alle 17:15 (protezione 63 ore)",
            f"6. Interesse Composto di Kelly (Budget Composto: {compounded_budget_eur:.2f} EUR -> Taglia Cartuccia: {dynamic_cartridge_eur:.2f} EUR)",
            "7. Vincolo di Markowitz (4 cartucce su 4 settori industriali diversi, mai doppio chip ASML+IFX)",
            "8. Scudo Elastico sulla Volatilità Reale ATR a 5m (si stringe su mercato piatto, si allarga su mercato esplosivo)",
            "9. Sblocco Titolo Immobile (>4h sotto VWAP) + Scarico Fiscale Modello 730 su occasione estrema",
            f"10. Cassaforte Giornaliera High-Water Mark (>= +1,80 EUR in cassa -> Attiva ora: {daily_vault_active})",
            "11. Fusione Zero-Latency 0ms (Incolla i prezzi in tempo reale di Trading 212 sulle candele 5m eliminando i 15m di ritardo di Yahoo su XETRA)",
            "12. Scudo Anti-Shock Dati Macro USA 14:28-14:35 (Blocca nuovi acquisti nei 7 minuti di caccia agli stop sui dati CPI/NFP delle 14:30)",
        ],
        "regime_mercato_attivo": regime,
        "radar_onda_notturna_wall_street": overnight_status,
        "account_id": 52318994,
        "budget_iniziale_vincolato_eur": 100.00,
        "budget_composto_attivo_kelly_eur": compounded_budget_eur,
        "taglia_cartuccia_composta_eur": dynamic_cartridge_eur,
        "cassaforte_giornaliera_attiva": daily_vault_active,
        "capitale_impegnato_cartucce_eur": round(invested_100e, 2),
        "liquidita_libera_su_100e_eur": free_cash_100e,
        "profitto_realizzato_in_cassa_eur": realized_net_eur,
        "profitto_aperto_non_realizzato_eur": round(unrealized_pnl_100e, 2),
        "guadagno_totale_netto_eur": round(realized_net_eur + unrealized_pnl_100e, 2),
        "valore_totale_portafoglio_100e_eur": virtual_100e_equity,
        "target_incasso_automatico_eur": bot.target_equity_eur,
        "commissioni_pagate_eur": 0.00,
        "classifica_scanner_quantitativo_5m": ranked_candidates,
        "titoli_in_cooldown_anti_massimi": intel.last_sell_price,
        "cartucce_4x25_eur": cartridge_statuses,
        "ultime_azioni_bot": actions_taken,
        "riepilogo_fiscale_730": bot.tax_tracker.generate_730_summary(virtual_100e_equity),
    }

    with open(BOT_STATE_PATH, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)

    return state


def main():
    print(
        "=== AVVIO DEMONE V6.0 ISTITUZIONALE: 10 BLINDATURE (MARKOWITZ + KELLY + ATR + ZAINETTO 730) ===",
        flush=True,
    )
    client = load_client()
    bot = Trading212AutonomousBot(client=client, total_budget_eur=100.00, cartridges=4, annual_target_pct=0.30)
    intel = HybridUncappedIntelligence()
    scanner = QuantMarketScanner()
    radar = OvernightWaveRadar()

    cycle = 1
    while True:
        try:
            state = run_cycle(bot, intel, scanner, radar, cycle)
            ov = state["radar_onda_notturna_wall_street"]
            print(
                f"[{state['timestamp']}] Ciclo #{cycle} | "
                f"Valore 100€: {state['valore_totale_portafoglio_100e_eur']:.2f} EUR "
                f"(Cassa: {state['profitto_realizzato_in_cassa_eur']:+.2f} EUR, "
                f"Aperto: {state['profitto_aperto_non_realizzato_eur']:+.2f} EUR, "
                f"Cartuccia Kelly: {state['taglia_cartuccia_composta_eur']:.2f} EUR) | "
                f"Radar Notte: {ov['verdict']} (Nasdaq {ov['nasdaq_change_pct']:+.2f}%, VIX {ov['vix_fear_change_pct']:+.2f}%)",
                flush=True,
            )
            for act in state["ultime_azioni_bot"]:
                print(f"   >>> [AZIONE V6.0]: {act}", flush=True)
        except Exception as e:
            print(f"[ATTENZIONE] Errore temporaneo nel ciclo #{cycle}: {e}", flush=True)

        cycle += 1
        time.sleep(30)


if __name__ == "__main__":
    main()
